import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MessageCircle, Phone, Users, Shield } from 'lucide-react-native';

export default function AuthWelcome() {
  return (
    <LinearGradient colors={['#25D366', '#128C7E']} style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <MessageCircle size={80} color="white" strokeWidth={1.5} />
        </View>
        
        <Text style={styles.title}>WhatsApp Clone</Text>
        <Text style={styles.subtitle}>Connect with friends and family around the world</Text>
        
        <View style={styles.featuresContainer}>
          <View style={styles.feature}>
            <MessageCircle size={24} color="white" />
            <Text style={styles.featureText}>Instant Messaging</Text>
          </View>
          <View style={styles.feature}>
            <Phone size={24} color="white" />
            <Text style={styles.featureText}>Voice & Video Calls</Text>
          </View>
          <View style={styles.feature}>
            <Users size={24} color="white" />
            <Text style={styles.featureText}>Group Chats</Text>
          </View>
          <View style={styles.feature}>
            <Shield size={24} color="white" />
            <Text style={styles.featureText}>End-to-End Encryption</Text>
          </View>
        </View>
        
        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={styles.primaryButton}
            onPress={() => router.push('/auth/register')}
          >
            <Text style={styles.primaryButtonText}>Get Started</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.secondaryButton}
            onPress={() => router.push('/auth/login')}
          >
            <Text style={styles.secondaryButtonText}>I have an account</Text>
          </TouchableOpacity>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconContainer: {
    marginBottom: 30,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.9)',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 22,
  },
  featuresContainer: {
    marginBottom: 50,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  featureText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: 'white',
    marginLeft: 12,
  },
  buttonContainer: {
    width: '100%',
    gap: 12,
  },
  primaryButton: {
    backgroundColor: 'white',
    borderRadius: 25,
    paddingVertical: 16,
    alignItems: 'center',
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#25D366',
  },
  secondaryButton: {
    borderWidth: 2,
    borderColor: 'white',
    borderRadius: 25,
    paddingVertical: 16,
    alignItems: 'center',
  },
  secondaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: 'white',
  },
});