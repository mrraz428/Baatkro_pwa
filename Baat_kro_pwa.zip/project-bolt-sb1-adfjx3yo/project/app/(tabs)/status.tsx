import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, MoveVertical as MoreVertical, Plus } from 'lucide-react-native';

interface Status {
  id: string;
  name: string;
  time: string;
  avatar: string;
  hasViewed: boolean;
}

const MOCK_STATUSES: Status[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    time: '2 hours ago',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    hasViewed: false,
  },
  {
    id: '2',
    name: 'Bob Smith',
    time: '4 hours ago',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=400',
    hasViewed: true,
  },
  {
    id: '3',
    name: 'Emma Wilson',
    time: '6 hours ago',
    avatar: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=400',
    hasViewed: false,
  },
];

export default function StatusTab() {
  const [statuses] = useState<Status[]>(MOCK_STATUSES);

  const StatusItem = ({ status }: { status: Status }) => (
    <TouchableOpacity style={styles.statusItem}>
      <View style={[
        styles.avatarContainer,
        { borderColor: status.hasViewed ? '#ccc' : '#25D366' }
      ]}>
        <Image source={{ uri: status.avatar }} style={styles.avatar} />
      </View>
      <View style={styles.statusInfo}>
        <Text style={styles.statusName}>{status.name}</Text>
        <Text style={styles.statusTime}>{status.time}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Status</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton}>
            <Camera size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton}>
            <MoreVertical size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        <TouchableOpacity style={styles.myStatusContainer}>
          <View style={styles.myStatusAvatar}>
            <Image 
              source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400' }} 
              style={styles.avatar} 
            />
            <View style={styles.addStatusButton}>
              <Plus size={16} color="white" />
            </View>
          </View>
          <View style={styles.statusInfo}>
            <Text style={styles.myStatusTitle}>My Status</Text>
            <Text style={styles.myStatusSubtitle}>Tap to add status update</Text>
          </View>
        </TouchableOpacity>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent updates</Text>
        </View>

        <FlatList
          data={statuses}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <StatusItem status={item} />}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#075E54',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 16,
  },
  headerButton: {
    padding: 4,
  },
  content: {
    flex: 1,
    backgroundColor: 'white',
  },
  myStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  myStatusAvatar: {
    position: 'relative',
    marginRight: 16,
  },
  avatarContainer: {
    borderWidth: 2,
    borderRadius: 32,
    padding: 2,
    marginRight: 16,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  addStatusButton: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#25D366',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  statusInfo: {
    flex: 1,
  },
  myStatusTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#333',
    marginBottom: 2,
  },
  myStatusSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
  sectionHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#f5f5f5',
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#666',
    textTransform: 'uppercase',
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  statusName: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#333',
    marginBottom: 2,
  },
  statusTime: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
});