import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Phone, Video, PhoneCall, MoveVertical as MoreVertical } from 'lucide-react-native';

interface Call {
  id: string;
  name: string;
  time: string;
  avatar: string;
  type: 'incoming' | 'outgoing' | 'missed';
  callType: 'voice' | 'video';
}

const MOCK_CALLS: Call[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    time: '2:30 PM, Today',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    type: 'incoming',
    callType: 'video',
  },
  {
    id: '2',
    name: 'Bob Smith',
    time: '1:15 PM, Today',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=400',
    type: 'outgoing',
    callType: 'voice',
  },
  {
    id: '3',
    name: 'Emma Wilson',
    time: '11:45 AM, Today',
    avatar: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=400',
    type: 'missed',
    callType: 'voice',
  },
  {
    id: '4',
    name: 'Family Group',
    time: 'Yesterday, 8:30 PM',
    avatar: 'https://images.pexels.com/photos/3184613/pexels-photo-3184613.jpeg?auto=compress&cs=tinysrgb&w=400',
    type: 'incoming',
    callType: 'video',
  },
];

export default function CallsTab() {
  const [calls] = useState<Call[]>(MOCK_CALLS);

  const getCallIcon = (type: string) => {
    const iconColor = type === 'missed' ? '#ff4444' : '#25D366';
    return <PhoneCall size={16} color={iconColor} />;
  };

  const CallItem = ({ call }: { call: Call }) => (
    <TouchableOpacity style={styles.callItem}>
      <Image source={{ uri: call.avatar }} style={styles.avatar} />
      <View style={styles.callInfo}>
        <Text style={[
          styles.callName,
          call.type === 'missed' && styles.missedCallName
        ]}>
          {call.name}
        </Text>
        <View style={styles.callDetails}>
          {getCallIcon(call.type)}
          <Text style={styles.callTime}>{call.time}</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.callButton}>
        {call.callType === 'video' ? (
          <Video size={24} color="#25D366" />
        ) : (
          <Phone size={24} color="#25D366" />
        )}
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Calls</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton}>
            <MoreVertical size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        <FlatList
          data={calls}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <CallItem call={item} />}
          showsVerticalScrollIndicator={false}
        />
      </View>

      <TouchableOpacity style={styles.fab}>
        <PhoneCall size={24} color="white" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#075E54',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 16,
  },
  headerButton: {
    padding: 4,
  },
  content: {
    flex: 1,
    backgroundColor: 'white',
  },
  callItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 16,
  },
  callInfo: {
    flex: 1,
  },
  callName: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#333',
    marginBottom: 4,
  },
  missedCallName: {
    color: '#ff4444',
  },
  callDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  callTime: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
  callButton: {
    padding: 8,
  },
  fab: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#25D366',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
});