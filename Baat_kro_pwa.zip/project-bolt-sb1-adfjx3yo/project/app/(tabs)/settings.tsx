import { View, Text, StyleSheet, TouchableOpacity, Image, Switch } from 'react-native';
import { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { User, Bell, Shield, CircleHelp as HelpCircle, Info, LogOut, ChevronRight, Moon, Globe } from 'lucide-react-native';

export default function SettingsTab() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const SettingsItem = ({ 
    icon, 
    title, 
    subtitle, 
    onPress, 
    showArrow = true,
    rightElement 
  }: {
    icon: React.ReactNode;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    showArrow?: boolean;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity style={styles.settingsItem} onPress={onPress}>
      <View style={styles.settingsIcon}>
        {icon}
      </View>
      <View style={styles.settingsText}>
        <Text style={styles.settingsTitle}>{title}</Text>
        {subtitle && <Text style={styles.settingsSubtitle}>{subtitle}</Text>}
      </View>
      {rightElement || (showArrow && <ChevronRight size={20} color="#666" />)}
    </TouchableOpacity>
  );

  const handleLogout = () => {
    router.replace('/auth');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <View style={styles.content}>
        <TouchableOpacity style={styles.profileSection}>
          <Image 
            source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400' }} 
            style={styles.profileAvatar} 
          />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>John Doe</Text>
            <Text style={styles.profileStatus}>Hey there! I am using WhatsApp.</Text>
          </View>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>

        <View style={styles.settingsSection}>
          <SettingsItem
            icon={<User size={24} color="#25D366" />}
            title="Account"
            subtitle="Security notifications, change number"
          />
          
          <SettingsItem
            icon={<Shield size={24} color="#25D366" />}
            title="Privacy"
            subtitle="Block contacts, disappearing messages"
          />
          
          <SettingsItem
            icon={<Bell size={24} color="#25D366" />}
            title="Notifications"
            subtitle="Message, group & call tones"
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: '#ccc', true: '#25D366' }}
                thumbColor="white"
              />
            }
            showArrow={false}
          />
          
          <SettingsItem
            icon={<Moon size={24} color="#25D366" />}
            title="Dark Mode"
            subtitle="Switch to dark theme"
            rightElement={
              <Switch
                value={isDarkMode}
                onValueChange={setIsDarkMode}
                trackColor={{ false: '#ccc', true: '#25D366' }}
                thumbColor="white"
              />
            }
            showArrow={false}
          />
          
          <SettingsItem
            icon={<Globe size={24} color="#25D366" />}
            title="Language"
            subtitle="English"
          />
        </View>

        <View style={styles.settingsSection}>
          <SettingsItem
            icon={<HelpCircle size={24} color="#25D366" />}
            title="Help"
            subtitle="Help center, contact us, privacy policy"
          />
          
          <SettingsItem
            icon={<Info size={24} color="#25D366" />}
            title="About"
            subtitle="Version 2.24.1.78"
          />
        </View>

        <View style={styles.settingsSection}>
          <SettingsItem
            icon={<LogOut size={24} color="#ff4444" />}
            title="Log Out"
            onPress={handleLogout}
            showArrow={false}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#075E54',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  content: {
    flex: 1,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 16,
    marginBottom: 8,
  },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#333',
    marginBottom: 4,
  },
  profileStatus: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
  settingsSection: {
    backgroundColor: 'white',
    marginBottom: 8,
  },
  settingsItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingsIcon: {
    marginRight: 16,
  },
  settingsText: {
    flex: 1,
  },
  settingsTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#333',
    marginBottom: 2,
  },
  settingsSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
});