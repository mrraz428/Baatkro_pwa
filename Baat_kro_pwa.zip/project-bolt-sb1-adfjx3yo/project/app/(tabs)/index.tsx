import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useState } from 'react';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, MoveVertical as MoreVertical, CreditCard as Edit } from 'lucide-react-native';
import { ChatItem } from '@/components/ChatItem';

interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  avatar: string;
  isOnline: boolean;
  isGroup: boolean;
}

const MOCK_CHATS: Chat[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    lastMessage: 'Hey! How are you doing?',
    time: '2:30 PM',
    unreadCount: 2,
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    isOnline: true,
    isGroup: false,
  },
  {
    id: '2',
    name: 'Family Group',
    lastMessage: 'Mom: Don\'t forget dinner tonight!',
    time: '1:45 PM',
    unreadCount: 5,
    avatar: 'https://images.pexels.com/photos/3184613/pexels-photo-3184613.jpeg?auto=compress&cs=tinysrgb&w=400',
    isOnline: false,
    isGroup: true,
  },
  {
    id: '3',
    name: 'Bob Smith',
    lastMessage: 'Thanks for the help yesterday',
    time: '12:15 PM',
    unreadCount: 0,
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=400',
    isOnline: false,
    isGroup: false,
  },
  {
    id: '4',
    name: 'Work Team',
    lastMessage: 'Sarah: Meeting at 3 PM today',
    time: '11:30 AM',
    unreadCount: 1,
    avatar: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400',
    isOnline: false,
    isGroup: true,
  },
  {
    id: '5',
    name: 'Emma Wilson',
    lastMessage: 'See you at the coffee shop!',
    time: '10:45 AM',
    unreadCount: 0,
    avatar: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=400',
    isOnline: true,
    isGroup: false,
  },
];

export default function ChatsTab() {
  const [chats] = useState<Chat[]>(MOCK_CHATS);

  const handleChatPress = (chat: Chat) => {
    router.push(`/chat/${chat.id}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>WhatsApp</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton}>
            <Search size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton}>
            <MoreVertical size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ChatItem 
            chat={item} 
            onPress={() => handleChatPress(item)} 
          />
        )}
        style={styles.chatsList}
        showsVerticalScrollIndicator={false}
      />

      <TouchableOpacity style={styles.fab}>
        <Edit size={24} color="white" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#075E54',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 16,
  },
  headerButton: {
    padding: 4,
  },
  chatsList: {
    flex: 1,
  },
  fab: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#25D366',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
});